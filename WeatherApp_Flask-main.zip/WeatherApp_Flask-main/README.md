# WeatherApp
Python and Flask to provide current weather details of any city along with temperature.I use Open Weather Map API to get weather details.
All the required modules are in requirements.txt file.
Run the following command in the terminal to install the modules.
pip install -r requirements.txt
The final version of the weatherapp is on http://binu007.pythonanywhere.com.
